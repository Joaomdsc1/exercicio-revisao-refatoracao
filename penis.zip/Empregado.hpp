#ifndef EMPREGADO_H
#define EMPREGADO_H

#include <iostream>
#include <string>

class Empregado
{
public:
  double pagamentoMes(double horasTrabalhadas);
  double salarioHora;
  double quotaMensalVendas;
};

#endif