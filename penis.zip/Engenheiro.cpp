#include "Engenheiro.hpp"
#include <iostream>
using namespace std;

Engenheiro ::Engenheiro()
{
    this->nome = "";
    this->projetos = 0;
}