#include "Vendedor.hpp"

double Vendedor::quotaTotalAnual()
{
	return quotaMensalVendas * 12;
}